/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade.pkg28.pkg03.pkg2018;

/**
 *
 * @author Aluno
 */
class jOptionPane {

    static void showMessageDialog(Object object, String senha_invalida) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
